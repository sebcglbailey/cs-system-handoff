var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/getSymbols.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/getSymbols.js":
/*!***************************!*\
  !*** ./src/getSymbols.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_CSWeb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/CSWeb */ "./src/modules/CSWeb.js");
/* harmony import */ var _modules_CSiOS__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modules/CSiOS */ "./src/modules/CSiOS.js");
/* harmony import */ var _modules_CSAndroid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modules/CSAndroid */ "./src/modules/CSAndroid.js");
/* harmony import */ var _modules_CSText__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modules/CSText */ "./src/modules/CSText.js");






var LIBRARIES = {
  WebApp: _modules_CSWeb__WEBPACK_IMPORTED_MODULE_2__["default"],
  CSiOS: _modules_CSiOS__WEBPACK_IMPORTED_MODULE_3__["default"],
  CSAndroid: _modules_CSAndroid__WEBPACK_IMPORTED_MODULE_4__["default"],
  CSText: _modules_CSText__WEBPACK_IMPORTED_MODULE_5__["default"]
};
var libraryCheck = 'CSiOS';
var symbols = [];
var textStyles = [];

var iterateLayers = function iterateLayers(layers, index) {
  layers.forEach(function (layer, index) {
    if (layer.layers) {
      iterateLayers(layer.layers);
    }

    if (layer.type == "SymbolInstance") {
      var symbolName = layer.sketchObject.symbolMaster().name();
      var filter = LIBRARIES[libraryCheck].filter(function (symbol) {
        return symbol.names.includes(symbolName);
      });

      if (filter.length == 0 && !symbols.includes(symbolName)) {
        symbols.push(symbolName);
      }
    }

    if (layer.type == "Text" && libraryCheck == LIBRARIES.CSText) {
      var styleName = layer.sharedStyle.name;

      var _filter = LIBRARIES['CSText'].filter(function (text) {
        return styleName.includes(text.name);
      });

      if (_filter.length == 0 && !textStyles.includes(styleName)) {
        textStyles.push(styleName);
      }
    }
  });
};

var chooseLibrary = function chooseLibrary() {
  sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.getInputFromUser("Which library do you want to rename your layers to?", {
    type: sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.INPUT_TYPE.selection,
    possibleValues: Object.keys(LIBRARIES),
    initialValue: 'CSiOS'
  }, function (err, value) {
    if (err) {
      return;
    }

    libraryCheck = value;
    var document = sketch_dom__WEBPACK_IMPORTED_MODULE_0___default.a.Document.getSelectedDocument();
    var pages = document.pages;
    var selectedLayers = document.selectedLayers; // Iterate over all pages

    iterateLayers(selectedLayers && selectedLayers.length > 0 ? selectedLayers : pages);

    if (value == LIBRARIES.CSText) {
      console.log(textStyles.join(" /// "));
    } else {
      console.log(symbols.join(" /// "));
    }
  });
};

/* harmony default export */ __webpack_exports__["default"] = (function (context) {
  sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.message("Check the console – 💎 Sketch dev tools");
  chooseLibrary();
});

/***/ }),

/***/ "./src/modules/CSAndroid.js":
/*!**********************************!*\
  !*** ./src/modules/CSAndroid.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var symbols = [{
  componentName: '',
  names: ['']
}];
/* harmony default export */ __webpack_exports__["default"] = (symbols);

/***/ }),

/***/ "./src/modules/CSText.js":
/*!*******************************!*\
  !*** ./src/modules/CSText.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var styles = [{
  styleName: 'CSText:H1',
  name: 'Heading / Level 1'
}, {
  styleName: 'CSText:H2',
  name: 'Heading / Level 2'
}, {
  styleName: 'CSText:H3',
  name: 'Heading / Level 3'
}, {
  styleName: 'CSText:Body',
  name: 'Body / Level 1'
}, {
  styleName: 'CSText:Button',
  name: 'Special / Button'
}];
/* harmony default export */ __webpack_exports__["default"] = (styles);

/***/ }),

/***/ "./src/modules/CSWeb.js":
/*!******************************!*\
  !*** ./src/modules/CSWeb.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var symbols = [{
  componentName: '',
  names: ['']
}];
/* harmony default export */ __webpack_exports__["default"] = (symbols);

/***/ }),

/***/ "./src/modules/CSiOS.js":
/*!******************************!*\
  !*** ./src/modules/CSiOS.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
var symbols = [{
  componentName: "CSCellTitle",
  names: ["Cells/__Light/Text only/Title", "Cells/__Light/Text only/Title + Description", "Cells/__Light/With icon/Title", "Cells/__Light/With icon/Title + Description"]
}, {
  componentName: "CSCellDescriptionTitle",
  names: ["Cells/__Light/Text only/Description + Title", "Cells/__Light/With icon/Description + Title"]
}, {
  componentName: "CSCellValue",
  names: ["Cells/__Light/Text only/ Value"]
}];
/* harmony default export */ __webpack_exports__["default"] = (symbols);

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__getSymbols.js.map